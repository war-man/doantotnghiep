<?php
/**
 * Thiết lập thông tin kết nối
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define('DB_NAME', 'trung');
?>