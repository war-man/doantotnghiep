package apt.tutorial.connectmysqldb;

/**
 * Created by Trung1994 on 16-Mar-17.
 */

public class News {

    public String image;
    public String link;
    public String title;

    public News(String image, String link, String title) {
        this.image = image;
        this.link = link;
        this.title = title;
    }
}
