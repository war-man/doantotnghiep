package com.example.myapplication.View.TrangChu;

import com.example.myapplication.Model.ObjectClass.LoaiSanPham;

import java.util.List;

public interface ViewXuLyMenu {
    void HienThiDanhSachMenu(List<LoaiSanPham> loaiSanPhamList);
}
