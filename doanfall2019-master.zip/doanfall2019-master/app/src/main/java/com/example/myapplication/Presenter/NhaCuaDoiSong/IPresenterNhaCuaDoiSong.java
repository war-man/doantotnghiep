package com.example.myapplication.Presenter.NhaCuaDoiSong;

public interface IPresenterNhaCuaDoiSong {
    void LayDanhSachNhaCuaDoiSong();
}
