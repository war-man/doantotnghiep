package com.example.myapplication.View.TrangChu;

import com.example.myapplication.Model.ObjectClass.SanPham;

import java.util.List;

public interface ViewHienThiSanPhamTheoDanhMuc {
    void HienThiDanhSachSanPham(List<SanPham> sanPhamList);
    void LoiHienThiDanhSachSanPham();
}
