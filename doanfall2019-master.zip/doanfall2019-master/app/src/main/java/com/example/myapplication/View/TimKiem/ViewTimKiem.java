package com.example.myapplication.View.TimKiem;

import com.example.myapplication.Model.ObjectClass.SanPham;

import java.util.List;

public interface ViewTimKiem {
    void TimKiemThanhCong(List<SanPham> sanPhamList);
    void TimKiemThatBai();
}
