package com.example.myapplication.Model.ObjectClass;

public class ThuongHieu {
    int MATHUONGHIEU, LUOTMUA;
    String TENTHUONHIEU, HINHTHUONGHIEU;


    public int getMATHUONGHIEU() {
        return MATHUONGHIEU;
    }

    public void setMATHUONGHIEU(int MATHUONGHIEU) {
        this.MATHUONGHIEU = MATHUONGHIEU;
    }

    public int getLUOTMUA() {
        return LUOTMUA;
    }

    public void setLUOTMUA(int LUOTMUA) {
        this.LUOTMUA = LUOTMUA;
    }

    public String getTENTHUONHIEU() {
        return TENTHUONHIEU;
    }

    public void setTENTHUONHIEU(String TENTHUONHIEU) {
        this.TENTHUONHIEU = TENTHUONHIEU;
    }

    public String getHINHTHUONGHIEU() {
        return HINHTHUONGHIEU;
    }

    public void setHINHTHUONGHIEU(String HINHTHUONGHIEU) {
        this.HINHTHUONGHIEU = HINHTHUONGHIEU;
    }
}
