package com.example.myapplication.Model.ObjectClass;

public class ChiTietKhuyenMai {
    int MAKM, MASP, PHANTRAMKM;

    public int getMAKM() {
        return MAKM;
    }

    public void setMAKM(int MAKM) {
        this.MAKM = MAKM;
    }

    public int getMASP() {
        return MASP;
    }

    public void setMASP(int MASP) {
        this.MASP = MASP;
    }

    public int getPHANTRAMKM() {
        return PHANTRAMKM;
    }

    public void setPHANTRAMKM(int PHANTRAMKM) {
        this.PHANTRAMKM = PHANTRAMKM;
    }
}
