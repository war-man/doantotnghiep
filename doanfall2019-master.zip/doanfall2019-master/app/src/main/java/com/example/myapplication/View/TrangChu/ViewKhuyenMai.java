package com.example.myapplication.View.TrangChu;

import com.example.myapplication.Model.ObjectClass.KhuyenMai;

import java.util.List;

public interface ViewKhuyenMai {
    void HienThiDanhSachKhuyenMai(List<KhuyenMai> khuyenMaiList);
}
