package com.example.myapplication.View.GioHang;

import com.example.myapplication.Model.ObjectClass.SanPham;

import java.util.List;

public interface ViewGioHang {
    void HienThiDanhSachSanPhamTrongGioHang(List<SanPham> sanPhamList);
}
