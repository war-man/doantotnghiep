package com.example.myapplication.Presenter.TrangChu.XuLyMenu;

import android.content.Context;

import com.facebook.AccessToken;

public interface IPresenterXuLyMenu {
    void LayDanhSachMenu();
    AccessToken LayTenNguoiDungFaceBook();
}
