package com.example.myapplication.Presenter.GioHang;

import android.content.Context;

public interface IPresenterGioHang {
    void  LayDanhSachSanPhamTrongGioHang(Context context);
}
