package com.example.myapplication.Presenter.HienThiSanPhamTheoDanhMuc;

public interface IPresenterHienThiSanPhamTheoDanhMuc {
    void layDanhSachSanPhamTheoMaLoai(int masp, boolean kiemtra);
}
