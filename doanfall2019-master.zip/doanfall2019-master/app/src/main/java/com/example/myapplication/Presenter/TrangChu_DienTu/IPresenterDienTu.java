package com.example.myapplication.Presenter.TrangChu_DienTu;

public interface IPresenterDienTu {
    void LayDanhSachDienTu();
    //askdcbaksbckjasbcjksabckasbdc
}
