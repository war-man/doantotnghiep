package com.example.myapplication.Model.ObjectClass;

public interface ILoadMore {
    void LoadMore(int tongitem);
}
