package com.example.myapplication.Presenter.TimKiem;

public interface IPresenterTinKiem {
    void TimKiemSanPhamTheoTenSP(String tensp, int limit);

}
