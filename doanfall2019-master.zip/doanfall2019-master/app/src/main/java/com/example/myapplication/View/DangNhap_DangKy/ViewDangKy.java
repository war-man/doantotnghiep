package com.example.myapplication.View.DangNhap_DangKy;

public interface ViewDangKy {
    void DangKyThanhCong();
    void DangKyThatBai();
}
