package com.example.myapplication.Presenter.KhuyenMai;

public interface IPresenterKhuyenMai {

    void LayDanhSachKhuyenMai();
}
