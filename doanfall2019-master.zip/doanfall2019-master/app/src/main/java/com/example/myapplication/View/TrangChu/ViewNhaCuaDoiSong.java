package com.example.myapplication.View.TrangChu;

import com.example.myapplication.Model.ObjectClass.DienTu;
import com.example.myapplication.Model.ObjectClass.NhaCuaDoiSong;

import java.util.List;

public interface ViewNhaCuaDoiSong {
    void HienThiDanhSach(List<NhaCuaDoiSong> NhaCuaDoiSongs);
}
