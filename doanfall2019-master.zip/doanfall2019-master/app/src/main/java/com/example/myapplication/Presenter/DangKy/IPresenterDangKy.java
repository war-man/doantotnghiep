package com.example.myapplication.Presenter.DangKy;

import com.example.myapplication.Model.ObjectClass.NguoiDung;

public interface IPresenterDangKy {
    void ThucHienDangKy(NguoiDung nguoiDung);
}
