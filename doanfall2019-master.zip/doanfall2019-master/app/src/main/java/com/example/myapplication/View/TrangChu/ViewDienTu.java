package com.example.myapplication.View.TrangChu;

import com.example.myapplication.Model.ObjectClass.DienTu;
import com.example.myapplication.Model.ObjectClass.SanPham;
import com.example.myapplication.Model.ObjectClass.ThuongHieu;

import java.util.List;

public interface ViewDienTu {
    void HienThiDanhSach(List<DienTu> dienTus);
}
