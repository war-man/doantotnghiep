package com.example.nhomcuong.applockv3.model;


public interface TransferData {
public void tinhtoan(int position,String packet,boolean ischeck,String label);
}
