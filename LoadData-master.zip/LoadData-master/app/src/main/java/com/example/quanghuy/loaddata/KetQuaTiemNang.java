package com.example.quanghuy.loaddata;

/**
 * Created by QuangHuy on 4/8/2017.
 */

public class KetQuaTiemNang {
    public int id;
    public String chung;
    public String tiemnang;

    public KetQuaTiemNang(int id, String chung, String tiemnang) {
        this.id = id;
        this.chung = chung;
        this.tiemnang = tiemnang;
    }
}
