package com.example.quanghuy.loaddata;

/**
 * Created by QuangHuy on 4/3/2017.
 */

public class KetQuaTinhCach {
    public int id;
    public String chung;
    public String tinhcach;

    public KetQuaTinhCach(int id, String chung, String tinhcach) {
        this.id = id;
        this.chung = chung;
        this.tinhcach = tinhcach;
    }
}
