package com.example.quanghuy.loaddata;


public class KetQua {
    //Integer id;
    String Username;
    String urlHinh;
    String Tenchung;
    Integer TFRC;

    public KetQua( String username, String urlHinh, String tenchung, Integer TFRC) {
       // this.id = id;
        Username = username;
        this.urlHinh = urlHinh;
        Tenchung = tenchung;
        this.TFRC = TFRC;
    }
}