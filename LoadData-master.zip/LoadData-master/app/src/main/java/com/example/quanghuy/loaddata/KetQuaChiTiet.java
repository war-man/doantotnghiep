package com.example.quanghuy.loaddata;

/**
 * Created by QuangHuy on 3/30/2017.
 */

public class KetQuaChiTiet {
    public int id;
    public String thongtin;

    public KetQuaChiTiet(int id, String thongtin) {
        this.id = id;
        this.thongtin = thongtin;
    }
}
