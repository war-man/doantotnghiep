package com.example.quanghuy.loaddata;

/**
 * Created by QuangHuy on 4/5/2017.
 */

public class KetQuaNgheNghiep {
public  int id;
    public String chung;
    public byte[] nghenghiep;

    public KetQuaNgheNghiep(int id, String chung, byte[] nghenghiep) {
        this.id = id;
        this.chung = chung;
        this.nghenghiep = nghenghiep;
    }
}

