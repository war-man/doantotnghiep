package com.thongph.justnote.Database.Entity;

/**
 * Created by thong on 9/25/2015.
 */
public class Tags {
}
