package smartbook.hutech.edu.smartbook.model.bookviewer;

import java.util.ArrayList;

/**
 * Created by hienl on 7/2/2017.
 */

public class BookListPageModel extends ArrayList<BookPageModel> {

}
