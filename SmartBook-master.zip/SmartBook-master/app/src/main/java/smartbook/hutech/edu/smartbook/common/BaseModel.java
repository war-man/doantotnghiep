package smartbook.hutech.edu.smartbook.common;
/*
 * Created by Nhat Hoang on 30/06/2017.
 */

import java.io.Serializable;

public class BaseModel implements Serializable {
}
