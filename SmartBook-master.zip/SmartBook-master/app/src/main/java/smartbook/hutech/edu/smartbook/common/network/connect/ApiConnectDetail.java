package smartbook.hutech.edu.smartbook.common.network.connect;
/*
 * Created by Nhat Hoang on 30/06/2017.
 */

public class ApiConnectDetail {
    private String mBaseURL;

    public String getBaseURL() {
        return mBaseURL;
    }

    public void setBaseURL(String mBaseURL) {
        this.mBaseURL = mBaseURL;
    }

}
