package smartbook.hutech.edu.smartbook.common.interfaces;

import android.graphics.Bitmap;

/**
 * Created by hienl on 7/4/2017.
 */

public interface ISaveHighlight {
    void saveCurrentHighlight(Bitmap bitmap, int pageIndex);
}
