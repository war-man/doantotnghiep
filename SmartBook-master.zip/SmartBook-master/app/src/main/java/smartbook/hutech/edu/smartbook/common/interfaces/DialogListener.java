package smartbook.hutech.edu.smartbook.common.interfaces;

public interface DialogListener {
    void onConfirmClicked();
}
