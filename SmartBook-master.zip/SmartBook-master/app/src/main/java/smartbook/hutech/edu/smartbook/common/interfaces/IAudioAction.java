package smartbook.hutech.edu.smartbook.common.interfaces;

/**
 * Created by hienl on 7/6/2017.
 */

public interface IAudioAction {
    void onPlayAudio(String audioPath, int itemPos);
}
