package smartbook.hutech.edu.smartbook.model;

import smartbook.hutech.edu.smartbook.common.BaseModel;

/**
 * Created by hienl on 6/24/2017.
 */

public class Item extends BaseModel {
}
