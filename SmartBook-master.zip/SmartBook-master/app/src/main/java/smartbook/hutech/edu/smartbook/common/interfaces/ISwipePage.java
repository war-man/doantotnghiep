package smartbook.hutech.edu.smartbook.common.interfaces;

/**
 * Created by hienl on 7/3/2017.
 */

public interface ISwipePage {
    void swipePage(int page);
}
