package com.sava.mymoney.ITF;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View view, int position);
}
