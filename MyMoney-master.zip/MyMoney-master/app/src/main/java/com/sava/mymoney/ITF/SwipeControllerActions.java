package com.sava.mymoney.ITF;

public abstract class SwipeControllerActions {
    public void onRightClicked(int position) {}

}
