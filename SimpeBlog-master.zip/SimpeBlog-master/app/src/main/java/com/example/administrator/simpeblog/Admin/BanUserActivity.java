package com.example.administrator.simpeblog.Admin;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.administrator.simpeblog.R;
import com.google.firebase.auth.FirebaseAuth;

public class BanUserActivity extends AppCompatActivity {
    private Button mLogout;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ban_user);
        mLogout = (Button)findViewById(R.id.logout_btn);
        mAuth = FirebaseAuth.getInstance();

        mLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
            }
        });
    }

    @Override
    public void onBackPressed() {

    }
}
