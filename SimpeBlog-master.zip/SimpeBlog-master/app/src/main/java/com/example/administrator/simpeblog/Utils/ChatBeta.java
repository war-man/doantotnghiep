package com.example.administrator.simpeblog.Utils;

/**
 * Created by Administrator on 4/14/2017.
 */

public class ChatBeta {
    private String msg;
    private String username;
    private String image;

    public ChatBeta() {
    }

    public ChatBeta(String msg, String username, String image) {
        this.msg = msg;
        this.username = username;
        this.image = image;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
