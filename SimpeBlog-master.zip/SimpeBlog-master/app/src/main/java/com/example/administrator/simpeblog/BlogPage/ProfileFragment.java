package com.example.administrator.simpeblog.BlogPage;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.administrator.simpeblog.R;
import com.flaviofaria.kenburnsview.KenBurnsView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

/**
 * Created by Administrator on 3/30/2017.
 */

public class ProfileFragment extends Fragment {
    public ProfileFragment() {

    }
    private KenBurnsView mProfile_Image;
    private TextView mName;
    private Button mView_Post;
    private String mCurrentUser;
    private Button mSign_Out;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabaseUser;
    private TextView mEmail;
    private TextView mPhone;
    private TextView mPlace;

    private TextView mCareer;
    private FirebaseAuth.AuthStateListener mAuthListener;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View v = inflater.inflate(R.layout.activity_profile, container, false);
        mAuth =FirebaseAuth.getInstance();
        mProfile_Image = (KenBurnsView) v.findViewById(R.id.image_profile);
        mName = (TextView)v.findViewById(R.id.username_profile) ;
        mView_Post = (Button)v.findViewById(R.id.view_post_btn);
        mSign_Out = (Button)v.findViewById(R.id.sign_out_btn);
        mEmail = (TextView)v.findViewById(R.id.email_profile) ;
        mPhone = (TextView)v.findViewById(R.id.phone_profile) ;
        mPlace = (TextView)v.findViewById(R.id.address) ;
        mCareer = (TextView)v.findViewById(R.id.career) ;

        mCurrentUser = mAuth.getCurrentUser().getUid();
        mDatabaseUser = FirebaseDatabase.getInstance().getReference().child("Users");




        mSign_Out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();

            }
        });



        mDatabaseUser.child(mCurrentUser).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String username = (String)dataSnapshot.child("name").getValue();
                String image = (String)dataSnapshot.child("image").getValue();
                String email = (String) dataSnapshot.child("email").getValue();
                String phone = (String) dataSnapshot.child("phone").getValue();
                String address = (String) dataSnapshot.child("address").getValue();
                String career = (String)dataSnapshot.child("career").getValue();
                mName.setText(username);
                mEmail.setText(email);
                mPhone.setText(phone);
                mPlace.setText(address);
                mCareer.setText(career);
                Picasso.with(getActivity()).load(image).into(mProfile_Image);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mView_Post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ViewPost = new Intent(getActivity(), EditProfileActivity.class);
                ViewPost.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(ViewPost);
            }
        });



        return v;
    }



}
