package com.example.administrator.simpeblog.Utils;

/**
 * Created by Administrator on 4/14/2017.
 */

public class RoomList {
    private String roomname;

    public RoomList(String roomname) {
        this.roomname = roomname;
    }

    public RoomList() {
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }
}


