package com.example.administrator.simpeblog.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.administrator.simpeblog.R;
import com.example.administrator.simpeblog.Utils.DividerItemDecoration;
import com.example.administrator.simpeblog.Utils.RoomList;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.tapadoo.alerter.Alerter;

import static com.example.administrator.simpeblog.R.id.room_name;

public class ChatManageFragment extends Fragment {
    public ChatManageFragment(){

    }
    private RecyclerView mRoomList;
    private EditText mRoomEdit;
    private ImageButton mAdd_btn;
    private DatabaseReference mDatabaseChatRoom;
    private FirebaseAuth mAuth;
    private LinearLayoutManager mLinearLayout;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.activity_chat_manage_fragment,container, false);


        mRoomEdit = (EditText)v.findViewById(R.id.room_name_edittext);
        mAdd_btn = (ImageButton) v.findViewById(R.id.addroom_btn);
        mDatabaseChatRoom = FirebaseDatabase.getInstance().getReference().child("Chat");
        mAuth = FirebaseAuth.getInstance();

        mRoomList = (RecyclerView)v.findViewById(R.id.room_list_rec);
        mRoomList.setHasFixedSize(true);
        mLinearLayout = new LinearLayoutManager(getActivity());
        mRoomList.setLayoutManager(mLinearLayout);



        mAdd_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startAddRoom();


            }
        });


        return v ;
    }

    @Override
    public void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter <RoomList, RoomViewHolder> newRoomAdapter = new FirebaseRecyclerAdapter<RoomList, RoomViewHolder>(
                RoomList.class,
                R.layout.romlist_row,
                RoomViewHolder.class,
                mDatabaseChatRoom


        ) {
            @Override
            protected void populateViewHolder(RoomViewHolder viewHolder, RoomList model, int position) {
                final String room_key = getRef(position).getKey();
                viewHolder.setRoomname(model.getRoomname());
                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent roomIntent = new Intent(getActivity(),ChatBetaActivity.class);
                        roomIntent.putExtra("room_id",room_key);
                        startActivity(roomIntent);
                    }
                });
            }

        };
        mRoomList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        mRoomList.setAdapter(newRoomAdapter);
    }


    public  static class RoomViewHolder extends RecyclerView.ViewHolder{
        View mView;

        public RoomViewHolder (View itemView){
            super(itemView);
            mView = itemView;


        }

        public void setRoomname(String roomname){
            TextView room_list = (TextView)mView.findViewById(room_name);
            room_list.setText(roomname);
        }







    }










    private void startAddRoom() {
        final String roomname_val = mRoomEdit.getText().toString().toString();
        if(!TextUtils.isEmpty(roomname_val)){
            final DatabaseReference newRoom = mDatabaseChatRoom.push();
            mDatabaseChatRoom.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    newRoom.child("roomname").setValue(roomname_val);
                    mRoomEdit.setText("");
                    Alerter.create(getActivity())
                            .setTitle("Room Added")
                            .setText("The room add successfully...")
                            .setBackgroundColor(R.color.alertadd)
                            .setIcon(R.drawable.addalert)
                            .show();

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });


        }
    }


}
