package com.example.administrator.simpeblog.Admin;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.simpeblog.R;
import com.example.administrator.simpeblog.Utils.ChatBeta;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.administrator.simpeblog.R.id.chat_image;

public class ChatBetaActivity extends AppCompatActivity {

    private RecyclerView mChatList;
    private EditText mInputMessage;
    private ImageButton mSubmitBtn;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabaseChat;
    private FirebaseUser mCurrentUser;
    private DatabaseReference mDatabaseUSer;
    private String mRoomKey = null;
    private LinearLayoutManager mLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_beta);

        mChatList = (RecyclerView)findViewById(R.id.chat_list);
        mChatList.setHasFixedSize(false);

        mLinearLayout = new LinearLayoutManager(ChatBetaActivity.this);
//        mLinearLayout.setReverseLayout(true);
        mLinearLayout.setStackFromEnd(true);
        mChatList.setLayoutManager(mLinearLayout);

        mInputMessage = (EditText)findViewById(R.id.input_message);
        mSubmitBtn = (ImageButton) findViewById(R.id.submit_message);
        mAuth = FirebaseAuth.getInstance();
        mDatabaseChat = FirebaseDatabase.getInstance().getReference().child("Chat");
        mDatabaseChat.keepSynced(true);
        mCurrentUser = mAuth.getCurrentUser();
        mDatabaseUSer = FirebaseDatabase.getInstance().getReference().child("Users").child(mCurrentUser.getUid());
        mRoomKey = getIntent().getExtras().getString("room_id");


        mInputMessage.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    startChat();
                    handled = true;
                    InputMethodManager inputManager = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);

                    inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                            InputMethodManager.HIDE_NOT_ALWAYS);
                }
                return handled;
            }
        });

        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startChat();
                InputMethodManager inputManager = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);

                inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
            }
        });



    }


    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<ChatBeta, ChatViewHolder> firebaseRecyclerAdapter1 = new FirebaseRecyclerAdapter<ChatBeta, ChatViewHolder>(

                ChatBeta.class,
                R.layout.chat_row,
                ChatViewHolder.class,
                mDatabaseChat.child(mRoomKey).child("message")
        ) {
            @Override
            protected void populateViewHolder(ChatViewHolder viewHolder, ChatBeta model, int position) {

                viewHolder.setMsg(model.getMsg());
                viewHolder.setUsername(model.getUsername());
                viewHolder.setImage(getApplication(),model.getImage());
            }
        };
//        mChatList.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mChatList.setAdapter(firebaseRecyclerAdapter1);





    }


    public static class ChatViewHolder extends RecyclerView.ViewHolder{
        View mView;
        FirebaseAuth mAuth;

        public ChatViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            mAuth = FirebaseAuth.getInstance();




        }
        public void setUsername(String username){
            TextView comment_username = (TextView)mView.findViewById(R.id.chat_username);
            comment_username.setText(username);
        }
        public void setMsg(String msg){
            TextView message = (TextView)mView.findViewById(R.id.chat_message);
            message.setText(msg);
        }
        public void setImage(final Context ctx, final String image){
            final CircleImageView chatImage = (CircleImageView)mView.findViewById(chat_image);
            Picasso.with(ctx).load(image).networkPolicy(NetworkPolicy.OFFLINE).into(chatImage, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(ctx).load(image).into(chatImage);

                }
            });

        }
    }

    private void startChat() {
        final String message_val = mInputMessage.getText().toString().trim();
        if(!TextUtils.isEmpty(message_val)){
            final DatabaseReference newMessage = mDatabaseChat.child(mRoomKey).child("message").push();
            mDatabaseUSer.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    newMessage.child("msg").setValue(message_val);
                    newMessage.child("username").setValue(dataSnapshot.child("name").getValue());
                    newMessage.child("image").setValue(dataSnapshot.child("image").getValue());
                    mInputMessage.setText("");
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }else {
            Toast.makeText(ChatBetaActivity.this, "Chat message Field is empty !", Toast.LENGTH_SHORT).show();
        }
    }
}
