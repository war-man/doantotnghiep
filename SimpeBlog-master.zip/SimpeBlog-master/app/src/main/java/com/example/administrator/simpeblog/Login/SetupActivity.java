package com.example.administrator.simpeblog.Login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.administrator.simpeblog.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

public class SetupActivity extends AppCompatActivity {
    private CircleImageView mSetupImageBtn;
    private EditText mNameField;
    private Button mSubmitBtn;
    private Uri mImageUri;
    private EditText mPhoneField;
    private EditText mAddressField;
    private EditText mCareer;
    private static final int GALLERY_REQUEST = 1;
    private DatabaseReference mDatabaseUsers;
    private FirebaseAuth mAuth;
    private StorageReference mStorageImage;
    private ProgressDialog mProgress;
    private FirebaseAuth.AuthStateListener mAuthListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.AppTheme1);
        setContentView(R.layout.activity_setup);

        mSetupImageBtn = (CircleImageView) findViewById(R.id.setupImageBtn);
        mNameField = (EditText)findViewById(R.id.setupNameField);
        mPhoneField = (EditText)findViewById(R.id.setupPhoneField) ;
        mAddressField = (EditText)findViewById(R.id.setupAddressField);
        mCareer = (EditText)findViewById(R.id.setupCareerField) ;
        mSubmitBtn = (Button)findViewById(R.id.setupSubmitBtn);
        mDatabaseUsers = FirebaseDatabase.getInstance().getReference().child("Users");
        mAuth = FirebaseAuth.getInstance();
        mStorageImage = FirebaseStorage.getInstance().getReference().child("Profile_images");
        mProgress = new ProgressDialog(this);

        mSetupImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, GALLERY_REQUEST);

            }
        });

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() == null){
                    Intent loginIntent = new Intent(SetupActivity.this, LoginActivity.class);
                    loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(loginIntent);

                }
            }
        };


        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSetupAccount();
            }
        });




    }

    private void startSetupAccount() {
        final String name = mNameField.getText().toString().toString();
        final String user_id = mAuth.getCurrentUser().getUid();
        final String email = mAuth.getCurrentUser().getEmail();
        final String phone = mPhoneField.getText().toString();
        final String address = mAddressField.getText().toString();
        final String career = mCareer.getText().toString();


        if(!TextUtils.isEmpty(name) && mImageUri!=null &&!TextUtils.isEmpty(phone)&&!TextUtils.isEmpty(address)){
            mProgress.setMessage("Finishing Setup....");
            mProgress.show();

            StorageReference filepath = mStorageImage.child(mImageUri.getLastPathSegment());
            filepath.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    String downloadUri = taskSnapshot.getDownloadUrl().toString();
                    mDatabaseUsers.child(user_id).child("name").setValue(name);
                    mDatabaseUsers.child(user_id).child("image").setValue(downloadUri);
                    mDatabaseUsers.child(user_id).child("email").setValue(email);
                    mDatabaseUsers.child(user_id).child("role").setValue("user");
                    mDatabaseUsers.child(user_id).child("phone").setValue(phone);
                    mDatabaseUsers.child(user_id).child("address").setValue(address);
                    mDatabaseUsers.child(user_id).child("career").setValue(career);
                    mDatabaseUsers.child(user_id).child("ban").setValue("unban");
                    mProgress.dismiss();

                }
            });
        }else if(TextUtils.isEmpty(name)){
            Toasty.error(SetupActivity.this,"Please enter your name !",Toast.LENGTH_SHORT).show();
        }else if(mImageUri == null){
            Toasty.error(SetupActivity.this,"Please choose your profile image !",Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(phone)){
            Toasty.error(SetupActivity.this,"Please enter your phone number !",Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(address)){
            Toasty.error(SetupActivity.this,"Please enter your address !",Toast.LENGTH_SHORT).show();
        }
        else{
            Toasty.error(SetupActivity.this,"Something Wrong ! Please check again !",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == GALLERY_REQUEST && resultCode == RESULT_OK){

            Uri imageUri = data.getData();

            CropImage.activity(imageUri)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(this);

        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                mImageUri = result.getUri();
                mSetupImageBtn.setImageURI(mImageUri);
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }
    }
}
