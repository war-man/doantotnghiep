package com.example.administrator.simpeblog.BlogPage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.example.administrator.simpeblog.Login.LoginActivity;
import com.example.administrator.simpeblog.Login.MainActivity;
import com.example.administrator.simpeblog.Login.SetupActivity;
import com.example.administrator.simpeblog.R;
import com.example.administrator.simpeblog.Utils.Blog;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.github.javiersantos.materialstyleddialogs.MaterialStyledDialog;
import com.github.javiersantos.materialstyleddialogs.enums.Style;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;
import com.tapadoo.alerter.Alerter;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.administrator.simpeblog.R.id.profile_image;

public class ViewPostActivity extends AppCompatActivity {

    private RecyclerView mPost_Profile_List;
    private DatabaseReference mDatabase;
    private DatabaseReference mDatabaseUsers;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference mDatabaseCurrentUser;
    private Query mQueryCurrUser;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("View Post");
        setContentView(R.layout.activity_view_post);

        mAuth =FirebaseAuth.getInstance();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() == null){
                    Intent loginIntent = new Intent(ViewPostActivity.this, LoginActivity.class);
                    loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(loginIntent);

                }
            }
        };


        mDatabase = FirebaseDatabase.getInstance().getReference().child("Blog");
        mDatabase.keepSynced(true);
        mDatabaseUsers = FirebaseDatabase.getInstance().getReference().child("Users");

        mDatabaseCurrentUser =FirebaseDatabase.getInstance().getReference().child("Blog");
        String currentuserid = mAuth.getCurrentUser().getUid();
        mQueryCurrUser = mDatabaseCurrentUser.orderByChild("uid").equalTo(currentuserid);
        mDatabaseUsers.keepSynced(true);

        mPost_Profile_List = (RecyclerView)findViewById(R.id.view_post_recycle);
        mPost_Profile_List.setHasFixedSize(false);
        mPost_Profile_List.setLayoutManager(new LinearLayoutManager(this));



        checkUserExist();


    }


    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);



        FirebaseRecyclerAdapter<Blog,BlogViewHolder> firebaseRecyclerAdapter1 = new FirebaseRecyclerAdapter<Blog, BlogViewHolder>(
                Blog.class,
                R.layout.view_post_row,
                BlogViewHolder.class,
                mQueryCurrUser


        ) {
            @Override
            protected void populateViewHolder(final BlogViewHolder viewHolder, Blog model, int position) {

                final String post_key = getRef(position).getKey();



                viewHolder.setTitle(model.getTitle());
                viewHolder.setDesc(model.getDesc());
                viewHolder.setImage(getApplication(),model.getImage());
                viewHolder.setUsername(model.getUsername());

                viewHolder.setProfile_image(getApplication(),model.getProfile());



                viewHolder.mImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent singleBlogIntent = new Intent(ViewPostActivity.this,CommentActivity.class);
                        singleBlogIntent.putExtra("blog_id",post_key);
                        startActivity(singleBlogIntent);
                    }
                });


                viewHolder.mOption.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        PopupMenu myMenu = new PopupMenu(ViewPostActivity.this, viewHolder.mOption);
                        myMenu.inflate(R.menu.user_post_menu);
                        myMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {

                                switch (item.getItemId()){
                                    case R.id.menu_edit_post:
                                        Intent editPostIntent = new Intent(ViewPostActivity.this,EditPostActivity.class);
                                        editPostIntent.putExtra("post_id", post_key);
                                        startActivity(editPostIntent);
                                        break;
                                    case R.id.menu_delete:

                                        final MaterialStyledDialog.Builder dialogHeader_6 = new MaterialStyledDialog.Builder(ViewPostActivity.this)
                                                .setStyle(Style.HEADER_WITH_TITLE)
                                                .withDialogAnimation(true)
                                                .setTitle("Delete !")
                                                .setDescription("Are you sure to delete this post ? The post will be deleted permanently and cannot be recovered !")
                                                .setHeaderColor(R.color.dialog_1)
                                                .setPositiveText("Yes ! Do it !")

                                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                    @Override
                                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                        mDatabase.child(post_key).removeValue();
                                                        Alerter.create(ViewPostActivity.this)
                                                                .setTitle("DELETE POST")
                                                                .setText("The post have delete successfully...")
                                                                .setBackgroundColor(R.color.colorfab)
                                                                .setIcon(R.drawable.delete)
                                                                .show();
                                                    }
                                                })
                                                .setNegativeText("No ! Keep it !");
                                        dialogHeader_6.show();


                                        break;
                                }

                                return false;
                            }
                        });
                        myMenu.show();

                    }
                });







            }
        };
        mPost_Profile_List.setAdapter(firebaseRecyclerAdapter1);
    }

    private void checkUserExist() {
        if(mAuth.getCurrentUser()!=null){
            final String user_id = mAuth.getCurrentUser().getUid();
            mDatabaseUsers.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(!dataSnapshot.hasChild(user_id)){
                        Intent setupIntent = new Intent(ViewPostActivity.this, SetupActivity.class);
                        setupIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(setupIntent);

                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }


    }


    public  static class BlogViewHolder extends RecyclerView.ViewHolder{
        View mView;
        ImageView mImage;
        ImageView mOption;
        FirebaseAuth mAuth;

        public BlogViewHolder (View itemView){
            super(itemView);
            mView = itemView;
            mAuth = FirebaseAuth.getInstance();
            mImage = (ImageView)mView.findViewById(R.id.post_image);
            mOption = (ImageView)mView.findViewById(R.id.user_option);


        }





        public void setTitle(String title){
            TextView post_title = (TextView)mView.findViewById(R.id.post_title);
            post_title.setText(title);

        }
        public void setDesc(String desc){
            TextView post_desc = (TextView)mView.findViewById(R.id.post_desc);
            post_desc.setText(desc);

        }
        public void setUsername(String username){
            TextView post_username = (TextView)mView.findViewById(R.id.post_username);
            post_username.setText(username);
        }

        public void setImage(final Context ctx, final String image){
            final ImageView post_image = (ImageView)mView.findViewById(R.id.post_image);
            // Picasso.with(ctx).load(image).into(post_image);
            Picasso.with(ctx).load(image).networkPolicy(NetworkPolicy.OFFLINE).into(post_image, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(ctx).load(image).into(post_image);

                }
            });
        }
        public  void setProfile_image (final Context ctx, final String profile){
            final CircleImageView post_profile = (CircleImageView)mView.findViewById(profile_image);
            Picasso.with(ctx).load(profile).networkPolicy(NetworkPolicy.OFFLINE).into(post_profile, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(ctx).load(profile).into(post_profile);

                }
            });
        }




    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(ViewPostActivity.this, MainActivity.class));
        super.onBackPressed();
    }
}
