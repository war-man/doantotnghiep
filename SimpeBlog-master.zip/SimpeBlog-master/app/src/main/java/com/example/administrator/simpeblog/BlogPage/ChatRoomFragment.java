package com.example.administrator.simpeblog.BlogPage;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.administrator.simpeblog.Admin.ChatBetaActivity;
import com.example.administrator.simpeblog.R;
import com.example.administrator.simpeblog.Utils.RoomList;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static com.example.administrator.simpeblog.R.id.room_name;

public class ChatRoomFragment extends Fragment {
    public ChatRoomFragment(){

    }
    private RecyclerView mRoomList;
    private DatabaseReference mDatabaseChatRoom;
    private FirebaseAuth mAuth;
    private LinearLayoutManager mLinearLayout;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.activity_chat_room,container, false);



        mDatabaseChatRoom = FirebaseDatabase.getInstance().getReference().child("Chat");
        mAuth = FirebaseAuth.getInstance();

        mRoomList = (RecyclerView)v.findViewById(R.id.room_list_rec);
        mRoomList.setHasFixedSize(true);
        mLinearLayout = new LinearLayoutManager(getActivity());
        mRoomList.setLayoutManager(mLinearLayout);






        return v ;
    }

    @Override
    public void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter <RoomList, RoomViewHolder> newRoomAdapter = new FirebaseRecyclerAdapter<RoomList, RoomViewHolder>(
                RoomList.class,
                R.layout.romlist_row,
                RoomViewHolder.class,
                mDatabaseChatRoom


        ) {
            @Override
            protected void populateViewHolder(RoomViewHolder viewHolder, RoomList model, int position) {
                final String room_key = getRef(position).getKey();
                viewHolder.setRoomname(model.getRoomname());
                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent roomIntent = new Intent(getActivity(),ChatBetaActivity.class);
                        roomIntent.putExtra("room_id",room_key);
                        startActivity(roomIntent);
                    }
                });
            }

        };
//        mRoomList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        mRoomList.setAdapter(newRoomAdapter);
    }


    public  static class RoomViewHolder extends RecyclerView.ViewHolder{
        View mView;

        public RoomViewHolder (View itemView){
            super(itemView);
            mView = itemView;


        }

        public void setRoomname(String roomname){
            TextView room_list = (TextView)mView.findViewById(room_name);
            room_list.setText(roomname);
        }







    }



}
