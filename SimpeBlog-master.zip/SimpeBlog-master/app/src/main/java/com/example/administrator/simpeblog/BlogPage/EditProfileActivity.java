package com.example.administrator.simpeblog.BlogPage;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.simpeblog.Login.MainActivity;
import com.example.administrator.simpeblog.R;
import com.flaviofaria.kenburnsview.KenBurnsView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import es.dmoral.toasty.Toasty;

public class EditProfileActivity extends AppCompatActivity {

    private KenBurnsView mProfile_Image;
    private TextView mNameDisplay;
    private Button mSave_btn;
    private String mCurrentUser;
    private Button mCancel;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabaseUser;
    private EditText mName;
    private EditText mPhone;
    private EditText mPlace;
    private EditText mCareer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        mAuth =FirebaseAuth.getInstance();
        mProfile_Image = (KenBurnsView)findViewById(R.id.image_profile);
        mNameDisplay = (TextView)findViewById(R.id.username_profile) ;
        mSave_btn = (Button)findViewById(R.id.submit_btn);
        mCancel = (Button)findViewById(R.id.cancel_btn);
        mName = (EditText) findViewById(R.id.name_textfield) ;
        mPhone = (EditText) findViewById(R.id.phone_textfield) ;
        mPlace = (EditText) findViewById(R.id.place_textfield) ;
        mCareer = (EditText) findViewById(R.id.career_textfield) ;

        mCurrentUser = mAuth.getCurrentUser().getUid();
        mDatabaseUser = FirebaseDatabase.getInstance().getReference().child("Users");

        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent CancelIntent = new Intent(EditProfileActivity.this, MainActivity.class);
                CancelIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(CancelIntent);
                Toasty.info(EditProfileActivity.this,"Update cancel !",Toast.LENGTH_SHORT).show();
            }
        });


        mSave_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StartEditProfile();
            }
        });


        mDatabaseUser.child(mCurrentUser).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String username = (String)dataSnapshot.child("name").getValue();
                String image = (String)dataSnapshot.child("image").getValue();
                String email = (String) dataSnapshot.child("email").getValue();
                String phone = (String) dataSnapshot.child("phone").getValue();
                String address = (String) dataSnapshot.child("address").getValue();
                String career = (String)dataSnapshot.child("career").getValue();
                mNameDisplay.setText(username);
                Picasso.with(EditProfileActivity.this).load(image).into(mProfile_Image);
                mName.setText(username);
                mPhone.setText(phone);
                mPlace.setText(address);
                mCareer.setText(career);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    private void StartEditProfile() {
        final String name_val = mName.getText().toString().trim();
        final String phone_val = mPhone.getText().toString().trim();
        final String career_val = mCareer.getText().toString().trim();
        final String place_val = mPlace.getText().toString().trim();

        if(!TextUtils.isEmpty(name_val) && !TextUtils.isEmpty(phone_val) && !TextUtils.isEmpty(career_val) && !TextUtils.isEmpty(place_val)){
            final DatabaseReference editProfile = mDatabaseUser.child(mCurrentUser);
            editProfile.child("name").setValue(name_val);
            editProfile.child("phone").setValue(phone_val);
            editProfile.child("address").setValue(place_val);
            editProfile.child("career").setValue(career_val).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        startActivity(new Intent(EditProfileActivity.this, MainActivity.class));
                        Toasty.success(EditProfileActivity.this,"Profile update successfull !", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else if(TextUtils.isEmpty(name_val)){
            Toasty.error(EditProfileActivity.this,"Name field can't be null !", Toast.LENGTH_SHORT).show();
            mName.requestFocus();
        }else if(TextUtils.isEmpty(phone_val)) {
            Toasty.error(EditProfileActivity.this, "Phone field can't be null !", Toast.LENGTH_SHORT).show();
            mPhone.requestFocus();
        }else if(TextUtils.isEmpty(place_val)) {
            Toasty.error(EditProfileActivity.this, "Place field can't be null !", Toast.LENGTH_SHORT).show();
            mPlace.requestFocus();
        }else if(TextUtils.isEmpty(career_val)) {
            Toasty.error(EditProfileActivity.this, "Career field can't be null !", Toast.LENGTH_SHORT).show();
            mCareer.requestFocus();
        }



    }
}
