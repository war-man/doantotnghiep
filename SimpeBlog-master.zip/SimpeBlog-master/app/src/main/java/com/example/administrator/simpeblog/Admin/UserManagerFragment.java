package com.example.administrator.simpeblog.Admin;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.example.administrator.simpeblog.R;
import com.example.administrator.simpeblog.Utils.DividerItemDecoration;
import com.example.administrator.simpeblog.Utils.UsersManager;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.github.javiersantos.materialstyleddialogs.MaterialStyledDialog;
import com.github.javiersantos.materialstyleddialogs.enums.Style;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

import static com.example.administrator.simpeblog.R.id.image_user;

public class UserManagerFragment extends Fragment {
    public UserManagerFragment() {

    }
    private DatabaseReference mDatabaseUsers;
    private RecyclerView mUser_list;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private CoordinatorLayout mLayout;

    @Override
    public  View onCreateView(LayoutInflater inflater, ViewGroup container,
                              Bundle savedInstanceState) {


        View v =inflater.inflate(R.layout.activity_user_manager,container, false);
        mDatabaseUsers = FirebaseDatabase.getInstance().getReference().child("Users");
        mDatabaseUsers.keepSynced(true);
        mUser_list = (RecyclerView)v.findViewById(R.id.users_list);
        mLayout = (CoordinatorLayout) v.findViewById(R.id.userfragmentlayout);
        mAuth =FirebaseAuth.getInstance();
        mUser_list.setHasFixedSize(true);
        mUser_list.setLayoutManager(new LinearLayoutManager(getActivity()));


        return v ;



    }


    @Override
    public void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<UsersManager,UsersViewHolder> firebaseRecyclerAdapter2 = new FirebaseRecyclerAdapter<UsersManager, UsersViewHolder>(
                UsersManager.class,
                R.layout.users_row,
                UsersViewHolder.class,
                mDatabaseUsers

        ) {
            @Override
            protected void populateViewHolder(final UsersViewHolder viewHolder, UsersManager model, int position) {
                final String user_key = getRef(position).getKey();
                viewHolder.setEmail(model.getEmail());
                viewHolder.setName(model.getName());
                viewHolder.setImage(getActivity(),model.getImage());

                mDatabaseUsers.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if(dataSnapshot.hasChild(user_key)){
                            String ban = (String)dataSnapshot.child(user_key).child("ban").getValue();
                            if(ban != null && ban.equals("ban")){
                                viewHolder.mStatus.setText("Banned");
                                viewHolder.mStatus.setTextColor(Color.parseColor("#f92c2c"));
                            }else{
                                viewHolder.mStatus.setText("Working");
                                viewHolder.mStatus.setTextColor(Color.parseColor("#1163dd"));

                            }
                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });


                viewHolder.mOption.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        PopupMenu myMenu = new PopupMenu(getContext(), viewHolder.mOption);
                        myMenu.inflate(R.menu.user_menu);
                        myMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.menu_reset:

                                        final MaterialStyledDialog.Builder dialogHeader_6 = new MaterialStyledDialog.Builder(getActivity())
                                                .setStyle(Style.HEADER_WITH_TITLE)
                                                .withDialogAnimation(true)
                                                .setTitle("Delete !")
                                                .setDescription("Are you sure to reset this user's profile ? Data will be deleted permanently and cannot be recovered !")
                                                .setHeaderColor(R.color.dialog_1)
                                                .setPositiveText("Yes ! Do it !")

                                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                    @Override
                                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                        mDatabaseUsers.child(user_key).removeValue();
                                                        Toasty.success(getActivity(), "Delete user successfull !", Toast.LENGTH_LONG).show();
                                                    }
                                                })
                                                .setNegativeText("No ! Keep it !");
                                        dialogHeader_6.show();
                                        break;
                                    case R.id.menu_ban:
                                        final MaterialStyledDialog.Builder dialogban = new MaterialStyledDialog.Builder(getActivity())
                                                .setStyle(Style.HEADER_WITH_TITLE)
                                                .withDialogAnimation(true)
                                                .setTitle("Ban User !")
                                                .setDescription("Are you sure to ban this user ? ")
                                                .setHeaderColor(R.color.dialog_1)
                                                .setPositiveText("Yes ")
                                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                    @Override
                                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                        mDatabaseUsers.child(user_key).child("ban").setValue("ban");
                                                        Toasty.error(getActivity(), "User has been banned !", Toast.LENGTH_LONG).show();
                                                    }
                                                })
                                                .setNegativeText("No");
                                        dialogban.show();
                                        break;
                                    case R.id.menu_unban:

                                        final MaterialStyledDialog.Builder dialogunban = new MaterialStyledDialog.Builder(getActivity())
                                                .setStyle(Style.HEADER_WITH_TITLE)
                                                .withDialogAnimation(true)
                                                .setTitle("UnBan User !")
                                                .setDescription("Are you sure to unban this user ? ")
                                                .setHeaderColor(R.color.dialog_1)
                                                .setPositiveText("Yes ")

                                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                    @Override
                                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                        mDatabaseUsers.child(user_key).child("ban").setValue("unban");
                                                        Toasty.success(getActivity(), "User has been Unbanned !", Toast.LENGTH_LONG).show();
                                                    }
                                                })
                                                .setNegativeText("No");
                                        dialogunban.show();
                                        break;
                                }
                                return false;
                            }
                        });
                        myMenu.show();

                    }
                });

            }
        };
        mUser_list.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        mUser_list.setAdapter(firebaseRecyclerAdapter2);


    }

    public  static class UsersViewHolder extends RecyclerView.ViewHolder{
        View mView;
        ImageView mOption;
        TextView mStatus;
        FirebaseAuth mAuth;
        public UsersViewHolder (View itemView){
            super(itemView);
            mView = itemView;
            mAuth = FirebaseAuth.getInstance();
            mOption = (ImageView)mView.findViewById(R.id.option);
            //mOption = (TextView)mView.findViewById(R.id.txtOption);
            mStatus = (TextView)mView.findViewById(R.id.user_status);


        }


        public void setName (String name){
            TextView username = (TextView)mView.findViewById(R.id.username_user);
            username.setText(name);

        }
        public void setEmail (String email){
            TextView Eemail = (TextView)mView.findViewById(R.id.email_user);
            Eemail.setText(email);
        }

        public  void setImage (final Context ctx, final String image){
            final CircleImageView post_profile = (CircleImageView)mView.findViewById(image_user);
            Picasso.with(ctx).load(image).networkPolicy(NetworkPolicy.OFFLINE).into(post_profile, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(ctx).load(image).into(post_profile);

                }
            });

        }
    }

}
