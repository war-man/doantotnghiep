package com.example.administrator.simpeblog.BlogPage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.administrator.simpeblog.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import es.dmoral.toasty.Toasty;

public class EditPostActivity extends AppCompatActivity {

    private String mPost_Key;
    private DatabaseReference mDatabase;
    private EditText mEditTitle;
    private EditText mEditDesc;
    private ImageButton mEditImage;
    private Button mEditBtn;
    private ProgressDialog mProgress;
    private DatabaseReference mDatabaseUser;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_post);

        mPost_Key = getIntent().getExtras().getString("post_id");
        mDatabase = FirebaseDatabase.getInstance().getReference().child("Blog");
        mEditTitle = (EditText)findViewById(R.id.edit_titleField) ;
        mEditDesc = (EditText) findViewById(R.id.edit_descField);
        mEditImage = (ImageButton) findViewById(R.id.edit_imageSelect);
        mEditBtn = (Button)findViewById(R.id.edit_Btn) ;
        mProgress = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String title = (String)dataSnapshot.child(mPost_Key).child("title").getValue();
                String desc = (String) dataSnapshot.child(mPost_Key).child("desc").getValue();
                String image = (String) dataSnapshot.child(mPost_Key).child("image").getValue();
                mEditTitle.setText(title);
                mEditDesc.setText(desc);
                Picasso.with(EditPostActivity.this).load(image).into(mEditImage);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mEditBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startEditPost();
            }
        });




    }

    private void startEditPost() {
        mProgress.setMessage("Editing Post....");
        mProgress.show();

        final String title_val =  mEditTitle.getText().toString().trim();
        final String desc_val = mEditDesc.getText().toString().trim();

        if (!TextUtils.isEmpty(title_val) && !TextUtils.isEmpty(desc_val)) {
            final DatabaseReference editPost = mDatabase.child(mPost_Key);
            editPost.child("title").setValue(title_val);
            editPost.child("desc").setValue(desc_val).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        startActivity(new Intent(EditPostActivity.this, ViewPostActivity.class));
                        Toasty.success(EditPostActivity.this,"Edit post successfull !", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else if(TextUtils.isEmpty(title_val)){
            Toasty.error(EditPostActivity.this,"Please enter title for your post !", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(desc_val)){
            Toasty.error(EditPostActivity.this,"Please enter description for your post !", Toast.LENGTH_SHORT).show();
        }
        mProgress.dismiss();



    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(EditPostActivity.this, ViewPostActivity.class));
        super.onBackPressed();
    }
}
