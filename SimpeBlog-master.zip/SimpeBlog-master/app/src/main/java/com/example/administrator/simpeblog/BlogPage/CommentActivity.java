package com.example.administrator.simpeblog.BlogPage;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.simpeblog.R;
import com.example.administrator.simpeblog.Utils.Comment;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jaeger.recyclerviewdivider.RecyclerViewDivider;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.administrator.simpeblog.R.id.comment_image;

public class CommentActivity extends AppCompatActivity {

    private RecyclerView mCommentList;
    private EditText mCommentEdit;
    private ImageButton mSubmitComment;
    private ProgressDialog mProgress;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabaseComment;
    private DatabaseReference mDatabaseComment2;
    private String mPost_key = null;
    private FirebaseUser mCurrentUser;
    private DatabaseReference mDatabaseUser;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private ImageView mPost_Image;
    private DatabaseReference mDatabaseLike;
    private TextView mLikeCount;
    private TextView mCommentCount;
    private ImageButton mCommentBtn;
    private TextView mCommentText;
    private boolean mProcessLike = false;
    private LikeButton mLikeBtn;
    private TextView mTextLike;
    private ScrollView scroll;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Comment");
        setContentView(R.layout.activity_comment);


        mCommentEdit = (EditText)findViewById(R.id.comment_edt);
        mSubmitComment = (ImageButton)findViewById(R.id.comment_submit_btn);
        mCommentList = (RecyclerView)findViewById(R.id.comment_list) ;
        mPost_Image = (ImageView)findViewById(R.id.comment_post_image) ;
        mLikeCount = (TextView)findViewById(R.id.like_count) ;
        mCommentCount = (TextView)findViewById(R.id.comment_count) ;
        mCommentBtn = (ImageButton)findViewById(R.id.comment_btn) ;
        mCommentText = (TextView)findViewById(R.id.textComment) ;
        mLikeBtn = (LikeButton)findViewById(R.id.like_btn) ;
        mTextLike = (TextView)findViewById(R.id.textLike) ;
        scroll = (ScrollView)findViewById(R.id.scrollview) ;

        mCommentList.setHasFixedSize(false);
        mCommentList.setLayoutManager(new LinearLayoutManager(this));
        mCommentList.setNestedScrollingEnabled(false);


        mProgress = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mDatabaseComment = FirebaseDatabase.getInstance().getReference().child("Blog");
        mDatabaseComment.keepSynced(true);
        mDatabaseLike = FirebaseDatabase.getInstance().getReference().child("Likes");


        mDatabaseUser = FirebaseDatabase.getInstance().getReference().child("Users").child(mCurrentUser.getUid());
        mPost_key = getIntent().getExtras().getString("blog_id");
//        mCommentEdit.requestFocus();
        RecyclerViewDivider divider = new RecyclerViewDivider.Builder(this)
                .setStyle(RecyclerViewDivider.Style.BETWEEN)
                .setMarginLeft(90)
                .setMarginRight(8)
                .build();
        mCommentList.addItemDecoration(divider);





        mCommentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCommentEdit.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(mCommentEdit, InputMethodManager.SHOW_IMPLICIT);
            }
        });

        mCommentText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCommentEdit.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(mCommentEdit, InputMethodManager.SHOW_IMPLICIT);
            }
        });



        mDatabaseLike.child(mPost_key).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();
                mLikeCount.setText(Long.toString(count));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mDatabaseComment.child(mPost_key).child("comment").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                long count = dataSnapshot.getChildrenCount();
                mCommentCount.setText(Long.toString(count));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });







        mDatabaseComment.child(mPost_key).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String image_val = (String)dataSnapshot.child("image").getValue();
                Picasso.with(CommentActivity.this).load(image_val).into(mPost_Image);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        mCommentEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    startComment();

                    handled = true;
                    InputMethodManager inputManager = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);

                    inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                            InputMethodManager.HIDE_NOT_ALWAYS);
                }
                return handled;
            }
        });


        mSubmitComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startComment();
                InputMethodManager inputManager = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);

                inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
            }
        });



        mLikeBtn.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                checkLike(mPost_key);
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                checkLike(mPost_key);


            }
        });
        setLikeBtn(mPost_key);


        mTextLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkLike(mPost_key);

            }
        });




    }


    @Override
    protected void onStart() {
        super.onStart();
        //mAuth.addAuthStateListener(mAuthListener);
        FirebaseRecyclerAdapter <Comment, CommentViewHolder> firebaseRecyclerAdapter1 = new FirebaseRecyclerAdapter<Comment, CommentViewHolder>(

                Comment.class,
                R.layout.comment_row,
                CommentViewHolder.class,
                mDatabaseComment.child(mPost_key).child("comment")
        ) {
            @Override
            protected void populateViewHolder(final CommentViewHolder viewHolder, Comment model, int position) {

                viewHolder.setComment(model.getComment());
                viewHolder.setUsername(model.getUsername());
                viewHolder.setImage(getApplication(),model.getImage());




            }
        };

        mCommentList.setAdapter(firebaseRecyclerAdapter1);






    }

    public static class CommentViewHolder extends RecyclerView.ViewHolder{
        View mView;
        FirebaseAuth mAuth;

        public CommentViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            mAuth = FirebaseAuth.getInstance();





        }
        public void setUsername(String username){
            TextView comment_username = (TextView)mView.findViewById(R.id.cmt_username);
            comment_username.setText(username);
        }
        public void setComment(String comment){
            TextView comment_comment = (TextView)mView.findViewById(R.id.cmt_cmt);
            comment_comment.setText(comment);
        }
        public void setImage(final Context ctx, final String image){
            final CircleImageView commentImage = (CircleImageView)mView.findViewById(comment_image);
            Picasso.with(ctx).load(image).networkPolicy(NetworkPolicy.OFFLINE).into(commentImage, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(ctx).load(image).into(commentImage);

                }
            });

        }
    }

    private void startComment() {
        mProgress.setMessage("CommentActivity....");
        mProgress.show();
        final String comment_val = mCommentEdit.getText().toString().trim();
        if(!TextUtils.isEmpty(comment_val)){
            final DatabaseReference newComment = mDatabaseComment.child(mPost_key).child("comment").push();

            mDatabaseUser.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    newComment.child("comment").setValue(comment_val);
                    //newComment.child("uid").setValue(mCurrentUser.getUid());
                    newComment.child("username").setValue(dataSnapshot.child("name").getValue());
                    newComment.child("image").setValue(dataSnapshot.child("image").getValue());
                    mCommentEdit.setText("");
//                    finish();
//                    startActivity(getIntent());
                    scroll.fullScroll(View.FOCUS_DOWN);



                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            mProgress.dismiss();

        }else{
            Toast.makeText(CommentActivity.this,"Comment Field is empty !", Toast.LENGTH_SHORT).show();
            mProgress.dismiss();
        }


    }



    public void checkLike(final String mPost_key){
        mProcessLike = true;

        mDatabaseLike.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (mProcessLike) {
                    if (dataSnapshot.child(mPost_key).hasChild(mAuth.getCurrentUser().getUid())) {
                        mDatabaseLike.child(mPost_key).child(mAuth.getCurrentUser().getUid()).removeValue();
                        mProcessLike = false;

                    } else {
                        mDatabaseLike.child(mPost_key).child(mAuth.getCurrentUser().getUid()).setValue("RandomValue");
                        mProcessLike = false;
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void setLikeBtn(final String mPost_key){

        mDatabaseLike.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(mAuth.getCurrentUser() != null){
                    if(dataSnapshot.child(mPost_key).hasChild(mAuth.getCurrentUser().getUid())){
                        mLikeBtn.setLiked(true);
                        mTextLike.setEnabled(true);

                    }else {
                        mLikeBtn.setLiked(false);
                        mTextLike.setEnabled(true);

                    }
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



    }






}
