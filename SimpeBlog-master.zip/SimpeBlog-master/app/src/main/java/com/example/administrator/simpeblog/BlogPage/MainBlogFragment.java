package com.example.administrator.simpeblog.BlogPage;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.administrator.simpeblog.Admin.BanUserActivity;
import com.example.administrator.simpeblog.R;
import com.example.administrator.simpeblog.Utils.Blog;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.github.clans.fab.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.administrator.simpeblog.R.id.profile_image;

//import static com.example.administrator.simpeblog.R.id.fab;

public class MainBlogFragment extends Fragment {
    public MainBlogFragment() {

    }

    private RecyclerView mBlogList;
    private DatabaseReference mDatabase;
    private  DatabaseReference mDatabaseUsers;
    private DatabaseReference mDatabaseLike;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private boolean mProcessLike = false;
    private com.github.clans.fab.FloatingActionButton mFab_signout;
    private com.github.clans.fab.FloatingActionButton mFab_newpost;
    private FloatingActionButton mFab_viewpost;
    private LinearLayoutManager mLinearLayout;
    private android.support.design.widget.FloatingActionButton mFab_Add;
    private int mPreviousVisibleItem;
    private LikeButton mLikeButton;


    @Override
    public  View onCreateView(LayoutInflater inflater, ViewGroup container,
                              Bundle savedInstanceState) {


        View v =inflater.inflate(R.layout.activity_main_blog,container, false);


        mAuth =FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("Blog");
        mDatabase.keepSynced(true);
        mDatabaseUsers = FirebaseDatabase.getInstance().getReference().child("Users");
        mDatabaseLike = FirebaseDatabase.getInstance().getReference().child("Likes");
        mDatabaseUsers.keepSynced(true);
        mDatabaseLike.keepSynced(true);
        mFab_signout = (com.github.clans.fab.FloatingActionButton) v.findViewById(R.id.fab_logout);
        mFab_newpost = (com.github.clans.fab.FloatingActionButton) v.findViewById(R.id.fab_newpost);
        mFab_viewpost = (FloatingActionButton) v.findViewById(R.id.fab_viewpost);




        mFab_signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
            }
        });
        mFab_newpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(),PostActivity.class));
            }
        });
        mFab_viewpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(),ViewPostActivity.class));
            }
        });






        mBlogList = (RecyclerView)v.findViewById(R.id.blog_list);
        mBlogList.setHasFixedSize(true);

        mLinearLayout = new LinearLayoutManager(getActivity());
        mLinearLayout.setReverseLayout(true);
        mLinearLayout.setStackFromEnd(true);
        mBlogList.setLayoutManager(mLinearLayout);





        return v ;



    }




    @Override
    public void onStart() {
        super.onStart();





        FirebaseRecyclerAdapter<Blog,BlogViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Blog, BlogViewHolder>(
                Blog.class,
                R.layout.blog_row,
                BlogViewHolder.class,
                mDatabase


        ) {
            @Override
            protected void populateViewHolder(final BlogViewHolder viewHolder, Blog model, int position) {

                final String post_key = getRef(position).getKey();

                viewHolder.setTitle(model.getTitle());
                viewHolder.setDesc(model.getDesc());
                viewHolder.setImage(getActivity(),model.getImage());
                viewHolder.setUsername(model.getUsername());
                viewHolder.setLikeBtn(post_key);
                viewHolder.setProfile_image(getActivity(),model.getProfile());
                viewHolder.setAddress(model.getAddress());
                viewHolder.setTime(model.getTime());




                mDatabaseLike.child(post_key).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        long count = dataSnapshot.getChildrenCount();
                        viewHolder.mLikeCount.setText(Long.toString(count));
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                mDatabase.child(post_key).child("comment").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        long count = dataSnapshot.getChildrenCount();
                        viewHolder.mCommentCount.setText(Long.toString(count));
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



                viewHolder.mPost_Image.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent singleBlogIntent = new Intent(getActivity(),CommentActivity.class);
                        singleBlogIntent.putExtra("blog_id",post_key);
                        startActivity(singleBlogIntent);
                    }
                });




                viewHolder.mLikeBtn.setOnLikeListener(new OnLikeListener() {
                    @Override
                    public void liked(LikeButton likeButton) {
                        viewHolder.checkLike(post_key);
                    }

                    @Override
                    public void unLiked(LikeButton likeButton) {
                        viewHolder.checkLike(post_key);


                    }
                });


                viewHolder.mTextLike.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        viewHolder.checkLike(post_key);

                    }
                });


                viewHolder.mComment_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent singleBlogIntent = new Intent(getActivity(),CommentActivity.class);
                        singleBlogIntent.putExtra("blog_id",post_key);
                        startActivity(singleBlogIntent);
                    }
                });

                viewHolder.mCommnetText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent singleBlogIntent = new Intent(getActivity(),CommentActivity.class);
                        singleBlogIntent.putExtra("blog_id",post_key);
                        startActivity(singleBlogIntent);
                    }
                });






            }
        };
        mBlogList.setAdapter(firebaseRecyclerAdapter);
    }




    public  static class BlogViewHolder extends RecyclerView.ViewHolder{
        View mView;
        LikeButton mLikeBtn;
        DatabaseReference mDatabaseLike;
        FirebaseAuth mAuth;
        TextView mTextLike;
        TextView mCommnetText;
        ImageButton mComment_btn;
        TextView mLikeCount;
        TextView mCommentCount;
        TextView mPostTime;
        ImageView mPost_Image;
        boolean mProcessLike = false;
        public BlogViewHolder (View itemView){
            super(itemView);
            mView = itemView;
            mPost_Image = (ImageView)mView.findViewById(R.id.post_image) ;
            mLikeBtn = (LikeButton) mView.findViewById(R.id.like_btn);
            mTextLike = (TextView) mView.findViewById(R.id.textLike);
            mCommnetText = (TextView)mView.findViewById(R.id.textComment) ;
            mComment_btn = (ImageButton)mView.findViewById(R.id.comment_btn) ;
            mLikeCount = (TextView)mView.findViewById(R.id.likecount) ;
            mCommentCount = (TextView)mView.findViewById(R.id.commentCount) ;
            mPostTime = (TextView)mView.findViewById(R.id.post_time);
            mDatabaseLike = FirebaseDatabase.getInstance().getReference().child("Likes");
            mAuth = FirebaseAuth.getInstance();
            mDatabaseLike.keepSynced(true);

        }
        public void setLikeBtn(final String post_key){

            mDatabaseLike.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(mAuth.getCurrentUser() != null){
                        if(dataSnapshot.child(post_key).hasChild(mAuth.getCurrentUser().getUid())){
                            mLikeBtn.setLiked(true);
                            mTextLike.setEnabled(true);
                            mTextLike.setTextColor(Color.parseColor("#ed2f25"));
                            mTextLike.setText("Liked");
                        }else {
                            mLikeBtn.setLiked(false);
                            mTextLike.setEnabled(true);
                            mTextLike.setText("Like");
                            mTextLike.setTextColor(Color.parseColor("#FF80919C"));
                        }
                    }

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });



        }

        public void checkLike(final String post_key){
            mProcessLike = true;

            mDatabaseLike.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (mProcessLike) {
                        if (dataSnapshot.child(post_key).hasChild(mAuth.getCurrentUser().getUid())) {
                            mDatabaseLike.child(post_key).child(mAuth.getCurrentUser().getUid()).removeValue();
                            mProcessLike = false;

                        } else {
                            mDatabaseLike.child(post_key).child(mAuth.getCurrentUser().getUid()).setValue("RandomValue");
                            mProcessLike = false;
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }





        public void setTitle(String title){
            TextView post_title = (TextView)mView.findViewById(R.id.post_title);
            post_title.setText(title);

        }



        public void setTime(String time){
            TextView post_time = (TextView)mView.findViewById(R.id.post_time);
            post_time.setText(time);
        }

        public void setAddress(String address){
            TextView post_address = (TextView)mView.findViewById(R.id.locationtext);
            post_address.setText(address);
        }

        public void setDesc(String desc){
            TextView post_desc = (TextView)mView.findViewById(R.id.post_desc);
            post_desc.setText(desc);

        }
        public void setUsername(String username){
            TextView post_username = (TextView)mView.findViewById(R.id.post_username);
            post_username.setText(username);
        }

        public void setImage(final Context ctx, final String image){
            final ImageView post_image = (ImageView)mView.findViewById(R.id.post_image);
            Picasso.with(ctx).load(image).networkPolicy(NetworkPolicy.OFFLINE).into(post_image, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(ctx).load(image).into(post_image);

                }
            });
        }
        public  void setProfile_image (final Context ctx, final String profile){
            final CircleImageView post_profile = (CircleImageView)mView.findViewById(profile_image);
            Picasso.with(ctx).load(profile).networkPolicy(NetworkPolicy.OFFLINE).into(post_profile, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(ctx).load(profile).into(post_profile);

                }
            });
        }




    }
    public void checkBan(){
        if(mAuth.getCurrentUser()!=null){
            final String user_id = mAuth.getCurrentUser().getUid();
            mDatabaseUsers.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(dataSnapshot.hasChild(user_id)){
                        String ban = (String)dataSnapshot.child(user_id).child("ban").getValue();
                        if(ban != null && ban.equals("false")){
                            Intent setupIntent = new Intent(getActivity(), BlogActivity.class);
                            setupIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(setupIntent);
                        }else {
                            Intent setupIntent = new Intent(getActivity(), BanUserActivity.class);
                            setupIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(setupIntent);
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
    }




}
