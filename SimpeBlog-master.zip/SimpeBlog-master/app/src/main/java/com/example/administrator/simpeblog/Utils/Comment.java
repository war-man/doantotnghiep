package com.example.administrator.simpeblog.Utils;

/**
 * Created by Administrator on 3/19/2017.
 */

public class Comment {
    private String username;
    private String comment;
    private String image;

    public Comment() {
    }

    public Comment(String username, String comment, String image) {
        this.username = username;
        this.comment = comment;
        this.image = image;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
